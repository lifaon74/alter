import { IPathMatcher } from '../path-matcher/interfaces';
import { IRoute } from './interfaces';
import { IReadonlyList } from '@lifaon/observables';
import { IRoutePath} from './route-path/interfaces';
import { RoutePath } from './route-path/implementation';
import { IPathMatcherResult } from '../path-matcher/types';
import { IRouteOptions, TRouteExec, TRouteExecMode, TRouteExecParamsMode } from './types';
import { IRouteInternal, IRoutePrivate, ROUTE_PRIVATE } from './privates';
import { ConstructRoute } from './constructor';
import { IRoutePathEntry } from './route-path/types';

/** METHODS **/

/* GETTERS/SETTERS */

export function RouteGetChildren<TExecValue, TExecReturn>(instance: IRoute<TExecValue, TExecReturn>): IReadonlyList<IRoute<TExecReturn, any>> {
  return (instance as IRouteInternal<TExecValue, TExecReturn>)[ROUTE_PRIVATE].children;
}

export function RouteGetPathMatcher<TExecValue, TExecReturn>(instance: IRoute<TExecValue, TExecReturn>): IPathMatcher {
  return (instance as IRouteInternal<TExecValue, TExecReturn>)[ROUTE_PRIVATE].pathMatcher;
}

export function RouteGetExec<TExecValue, TExecReturn>(instance: IRoute<TExecValue, TExecReturn>): TRouteExec<TExecValue, TExecReturn> | null {
  return (instance as IRouteInternal<TExecValue, TExecReturn>)[ROUTE_PRIVATE].exec;
}

export function RouteGetExecMode<TExecValue, TExecReturn>(instance: IRoute<TExecValue, TExecReturn>): TRouteExecMode | null {
  return (instance as IRouteInternal<TExecValue, TExecReturn>)[ROUTE_PRIVATE].execMode;
}

export function RouteGetExecParamsMode<TExecValue, TExecReturn>(instance: IRoute<TExecValue, TExecReturn>): TRouteExecParamsMode | null {
  return (instance as IRouteInternal<TExecValue, TExecReturn>)[ROUTE_PRIVATE].execParamsMode;
}



/* METHODS */

export async function RouteResolve<TExecValue, TExecReturn>(instance: IRoute<TExecValue, TExecReturn>, path: string): Promise<IRoutePath | null> {
  // may resolve only if:

  const privates: IRoutePrivate<TExecValue, TExecReturn> = (instance as IRouteInternal<TExecValue, TExecReturn>)[ROUTE_PRIVATE];
  const match: IPathMatcherResult | null = privates.pathMatcher.exec(path);
  if (match === null) { // path doesnt match
    return null;
  } else {  // path matches
    //  we must check that privates.resolve() passes
    if (
      (privates.resolve === null)
      || await privates.resolve.call(instance, match)
    ) {
      const entry: IRoutePathEntry = {
        route: instance,
        params: match.params
      };

      // at least one child must resolve
      for (let i = 0, l = privates.children.length; i < l; i++) {
        const routePath: IRoutePath | null = await privates.children.item(i).resolve(match.remaining);
        if (routePath !== null) {
          return new RoutePath([entry, ...routePath.toArray()]);
        }
      }

      // except if no remaining path and exec is defined
      if (
        (match.remaining === '') // no remaining path
        && (privates.exec !== null) // if exec is undefined, path is invalid
      ) {
        return new RoutePath([entry]);
      } else {
        return null;
      }
    } else {
      return null;
    }
  }
}

// export async function RouteResolve(instance: IRoute, path: string): Promise<IRoutePath | null> {
//   // may resolve only if:
//
//   const privates: IRoutePrivate = (instance as IRouteInternal)[ROUTE_PRIVATE];
//   const match: IPathMatcherResult | null = privates.pathMatcher.exec(path);
//   if (match === null) { // path doesnt match
//     return null;
//   } else {  // path matches
//     const entry: IRoutePathEntry = {
//       route: instance,
//       params: match.params
//     };
//     if (match.remaining === '') { // no remaining path
//       if (
//         (privates.exec !== null) // if exec is undefined, path is invalid
//         && ( // if exec is defined, path is valid and we must check privates.resolve
//           (privates.resolve === null)
//           || await privates.resolve.call(instance, match)
//         )
//       ) {
//         return new RoutePath([entry]);
//       } else {
//         return null;
//       }
//     } else { // some remaining path
//       if (
//         (privates.resolve === null)
//         || await privates.resolve.call(instance, match)
//       ) {
//         // at least one child must resolve
//         for (let i = 0, l = privates.children.length; i < l; i++) {
//           const routePath: IRoutePath | null = await privates.children.item(i).resolve(match.remaining);
//           if (routePath !== null) {
//             return new RoutePath([entry, ...routePath.toArray()]);
//           }
//         }
//         return null;
//       } else {
//         return null;
//       }
//     }
//   }
// }

/** CLASS **/

export class Route<TExecValue, TExecReturn> implements IRoute<TExecValue, TExecReturn> {
  constructor(path: string, options?: IRouteOptions<TExecValue, TExecReturn>) {
    ConstructRoute(this, path, options);
  }

  get children(): IReadonlyList<IRoute<TExecReturn, any>> {
    return RouteGetChildren(this);
  }

  get pathMatcher(): IPathMatcher {
    return RouteGetPathMatcher<TExecValue, TExecReturn>(this);
  }

  get exec(): TRouteExec<TExecValue, TExecReturn> | null {
    return RouteGetExec<TExecValue, TExecReturn>(this);
  }

  get execMode(): TRouteExecMode | null {
    return RouteGetExecMode<TExecValue, TExecReturn>(this);
  }

  get execParamsMode(): TRouteExecParamsMode | null {
    return RouteGetExecParamsMode<TExecValue, TExecReturn>(this);
  }


  resolve(path: string): Promise<IRoutePath | null> {
    return RouteResolve<TExecValue, TExecReturn>(this, path);
  }
}

