import { IRoute } from './interfaces';
import { IPathMatcher } from '../path-matcher/interfaces';
import { IReadonlyList } from '@lifaon/observables';
import { TRouteExec, TRouteExecMode, TRouteExecParamsMode, TRouteResolve } from './types';

/** PRIVATES **/

export const ROUTE_PRIVATE = Symbol('route-private');

export interface IRoutePrivate<TExecValue, TExecReturn> {
  pathMatcher: IPathMatcher;
  children: IReadonlyList<IRoute<TExecReturn, any>>;
  resolve: TRouteResolve<TExecValue, TExecReturn> | null;
  exec: TRouteExec<TExecValue, TExecReturn> | null;
  execMode: TRouteExecMode | null;
  execParamsMode: TRouteExecParamsMode | null;
}

export interface IRoutePrivatesInternal<TExecValue, TExecReturn> {
  [ROUTE_PRIVATE]: IRoutePrivate<TExecValue, TExecReturn>;
}

export interface IRouteInternal<TExecValue, TExecReturn> extends IRoutePrivatesInternal<TExecValue, TExecReturn>, IRoute<TExecValue, TExecReturn> {
}
