import { IRoute } from '../interfaces';
import { TPathMatcherParams } from '../../path-matcher/types';
import { IAdvancedAbortSignal } from '@lifaon/observables';
import { IRouteExecParams } from '../types';

/** TYPES */

export type IRoutePathEntry = {
  route: IRoute<any, any>;
  params: TPathMatcherParams;
};

export interface IRoutePathExecOptions extends Partial<IRouteExecParams<any>> {
}
