import { IPathMatcher } from '../path-matcher/interfaces';
import { IReadonlyList } from '@lifaon/observables';
import { IRoutePath } from './route-path/interfaces';
import { IRouteOptions, TRouteExec, TRouteExecMode, TRouteExecParamsMode } from './types';

/** INTERFACES */

export interface IRouteConstructor {
  new<TExecValue, TExecReturn>(path: string, options?: IRouteOptions<TExecValue, TExecReturn>): IRoute<TExecValue, TExecReturn>;
}

export interface IRoute<TExec extends > {
  readonly children: IReadonlyList<IRoute<TExecReturn, any>>;
  readonly pathMatcher: IPathMatcher;
  readonly exec: TRouteExec<TExecValue, TExecReturn> | null;
  readonly execMode: TRouteExecMode | null;
  readonly execParamsMode: TRouteExecParamsMode | null;

  resolve(path: string): Promise<IRoutePath | null>;
}



