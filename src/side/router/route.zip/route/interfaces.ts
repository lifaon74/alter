import { IPathMatcher, IPathMatcherResult } from '../path-matcher/interfaces';
import { IReadonlyList, TPromiseOrValue } from '@lifaon/observables';

/** TYPES */

export type TRouteResolveMatchArgument = IPathMatcherResult;

export type TRouteResolve = (this: IRoute, math: TRouteResolveMatchArgument) => TPromiseOrValue<void>;
export type TRoutePreResolve = (this: IRoute, math: TRouteResolveMatchArgument, resolved: Promise<boolean>) => TPromiseOrValue<void>;

export interface IRouteOptions {
  children?: Iterable<IRoute>;
  onResolve?: TRouteResolve;
  onPreResolve?: TRoutePreResolve;
}

/** INTERFACES */

export interface IRouteConstructor {
  new(path: string, options?: IRouteOptions): IRoute;
}

export interface IRoute {
  readonly children: IReadonlyList<IRoute>;
  readonly pathMatcher: IPathMatcher;

  resolve(path: string): Promise<boolean>;
}



