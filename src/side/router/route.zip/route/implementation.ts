import { IPathMatcher, IPathMatcherResult } from '../path-matcher/interfaces';
import { PathMatcher } from '../path-matcher/implementation';
import { IRoute, IRouteOptions, TRoutePreResolve, TRouteResolve } from './interfaces';
import { IReadonlyList, ReadonlyList, TPromiseOrValue } from '@lifaon/observables';
import { ConstructClassWithPrivateMembers } from '../../../misc/helpers/ClassWithPrivateMembers';
import { IsObject } from '@lifaon/observables/src/helpers';

/** PRIVATES **/

export const ROUTE_PRIVATE = Symbol('route-private');

export interface IRoutePrivate {
  pathMatcher: IPathMatcher;
  children: IReadonlyList<IRoute>;
  onResolve: TRouteResolve | null;
  onPreResolve: TRoutePreResolve | null;
}

export interface IRouteInternal extends IRoute {
  [ROUTE_PRIVATE]: IRoutePrivate;
}

/** CONSTRUCTOR **/

export function ConstructRoute(
  instance: IRoute,
  path: string,
  options: IRouteOptions = {},
): void {
  ConstructClassWithPrivateMembers(instance, ROUTE_PRIVATE);
  const privates: IRoutePrivate = (instance as IRouteInternal)[ROUTE_PRIVATE];

  if (IsObject(options)) {
    if (typeof path === 'string') {
      privates.pathMatcher = new PathMatcher(path);
    } else {
      throw new TypeError(`Expected string as path`);
    }

    if (options.children === void 0) {
      privates.children = new ReadonlyList<IRoute>([]);
    } else if (Symbol.iterator in options.children) {
      const children: IRoute[] = Array.from(options.children);
      for (let i = 0, l = children.length; i < l; i++) {
        if (!IsRoute(children[i])) {
          throw new TypeError(`Expected Route at index #${ i } of options.children`);
        }
      }
      privates.children = new ReadonlyList<IRoute>(children);
    } else {
      throw new TypeError(`Expected array as options.children`);
    }

    if (options.onResolve === void 0) {
      privates.onResolve = null;
    } else if (typeof options.onResolve === 'function') {
      privates.onResolve = options.onResolve;
    } else {
      throw new TypeError(`Expected void or function as options.onResolve`);
    }

    if (options.onPreResolve === void 0) {
      privates.onPreResolve = null;
    } else if (typeof options.onPreResolve === 'function') {
      privates.onPreResolve = options.onPreResolve;
    } else {
      throw new TypeError(`Expected void or function as options.onPreResolve`);
    }
  } else {
    throw new TypeError(`Expected void or object as options`);
  }
}

export function IsRoute(value: any): value is IRoute {
  return IsObject(value)
    && value.hasOwnProperty(ROUTE_PRIVATE as symbol);
}

/** METHODS **/

/* GETTERS/SETTERS */

export function RouteGetChildren(instance: IRoute): IReadonlyList<IRoute> {
  return (instance as IRouteInternal)[ROUTE_PRIVATE].children;
}

export function RouteGetPathMatcher(instance: IRoute): IPathMatcher {
  return (instance as IRouteInternal)[ROUTE_PRIVATE].pathMatcher;
}

/* METHODS */

export async function RouteResolve(instance: IRoute, path: string): Promise<boolean> {
  // may resolve only if:

  const privates: IRoutePrivate = (instance as IRouteInternal)[ROUTE_PRIVATE];
  const match: IPathMatcherResult | null = privates.pathMatcher.exec(path);
  if (match === null) { // path doesnt match => return false
    return false;
  } else {  // path matches
    let resolve: (value?: TPromiseOrValue<boolean>) => void = () => {};
    const promise: Promise<boolean> = new Promise<boolean>(_resolve => (resolve = _resolve));
    if (privates.onPreResolve !== null) {
      await privates.onPreResolve.call(instance, match, promise);
    }

    if (match.remaining === '') { // no remaining path
      if (privates.onResolve === null) { // resolve is undefined => path is invalid
        resolve(false);
      } else { // resolve is defined => path is valid
        resolve(true);
        await privates.onResolve.call(instance, match);
      }
    } else { // some remaining path


      // at least one child must resolve
      for (let i = 0, l = privates.children.length; i < l; i++) {
        if (await privates.children[i].resolve(match.remaining)) {
          if (privates.onResolve !== null) {
            await privates.onResolve.call(instance, match);
          }
          return true;
        }
      }
      return false;
    }

    return promise;
  }
}

/** CLASS **/

export class Route implements IRoute {
  constructor(path: string, options?: IRouteOptions) {
    ConstructRoute(this, path, options);
  }

  get children(): IReadonlyList<IRoute> {
    return RouteGetChildren(this);
  }

  get pathMatcher(): IPathMatcher {
    return RouteGetPathMatcher(this);
  }

  resolve(path: string): Promise<boolean> {
    return RouteResolve(this, path);
  }
}

