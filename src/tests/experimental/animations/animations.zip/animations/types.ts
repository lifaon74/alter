export type TProgression = number; // progression ∈[0, 1]
export type TProgressionStates = 'start' | 'end';
export type TProgressionWithState = TProgression | TProgressionStates;


export type TProgressFunction<GArgs extends any[], GReturn> = (progression: TProgression, ...args: GArgs) => GReturn;
export type TProgressFunctionWithState<GArgs extends any[], GReturn> = (progression: TProgressionWithState, ...args: GArgs) => GReturn;

export type TGenericProgressFunction = TProgressFunction<any[], any>;
export type TGenericProgressFunctionWithState = TProgressFunctionWithState<any[], any>;

export type TInferProgressFunctionArguments<GFnc extends TGenericProgressFunction> =
  GFnc extends ((progression: TProgression | TProgressionWithState, ...args: infer GArgs) => any)
    ? GArgs
    : never;

export type TInferProgressFunctionReturns<GFnc extends TGenericProgressFunction> =
  GFnc extends ((progression: TProgression | TProgressionWithState, ...args: any[]) => infer GReturn)
    ? GReturn
    : never;


export type THTMLElements = ArrayLike<HTMLElement>;
